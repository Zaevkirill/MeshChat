package com.meshchat.app.ui.messenger

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.meshchat.app.data.Net
import com.meshchat.app.data.Prefs
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.UUID

data class Chat(val id: String, val name: String, val username: String, val last: String)
data class ChatMessage(val chatId: String, val text: String, val mine: Boolean)
data class DirUser(val username: String, val phone: String, val name: String)

class MessengerViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)

    val chats = mutableStateListOf<Chat>()
    val messages = mutableStateListOf<ChatMessage>()

    var query by mutableStateOf("")
    var results by mutableStateOf<List<DirUser>>(emptyList())
    var online by mutableStateOf(false)

    var meshEnabled by mutableStateOf(false)
    var bleEnabled by mutableStateOf(true)
    var wifiDirectEnabled by mutableStateOf(true)

    private var socket: WebSocket? = null
    private var loop: Job? = null
    private val pending = mutableListOf<String>()

    init {
        load()
    }

    // ---------- хранение на устройстве ----------

    private fun load() {
        try {
            val ca = JSONArray(prefs.chatsJson.ifEmpty { "[]" })
            for (i in 0 until ca.length()) {
                val o = ca.getJSONObject(i)
                chats.add(Chat(o.getString("id"), o.getString("name"), o.getString("username"), o.optString("last")))
            }
            val ma = JSONArray(prefs.messagesJson.ifEmpty { "[]" })
            for (i in 0 until ma.length()) {
                val o = ma.getJSONObject(i)
                messages.add(ChatMessage(o.getString("chatId"), o.getString("text"), o.getBoolean("mine")))
            }
        } catch (e: Exception) {
            // повреждённые данные игнорируем
        }
    }

    private fun save() {
        val ca = JSONArray()
        chats.forEach {
            ca.put(JSONObject().put("id", it.id).put("name", it.name).put("username", it.username).put("last", it.last))
        }
        val ma = JSONArray()
        messages.takeLast(500).forEach {
            ma.put(JSONObject().put("chatId", it.chatId).put("text", it.text).put("mine", it.mine))
        }
        prefs.chatsJson = ca.toString()
        prefs.messagesJson = ma.toString()
    }

    private fun ensureChat(id: String, name: String) {
        if (chats.none { it.id == id }) chats.add(Chat(id, name.ifBlank { id }, "@$id", ""))
    }

    private fun updateLast(chatId: String, text: String) {
        val i = chats.indexOfFirst { it.id == chatId }
        if (i >= 0) chats[i] = chats[i].copy(last = text)
    }

    // ---------- поиск и контакты ----------

    fun isContact(u: DirUser) = chats.any { it.id == u.username }

    fun addContact(u: DirUser) {
        ensureChat(u.username, u.name)
        save()
    }

    fun search() {
        val q = query.trim().removePrefix("@")
        if (q.length < 2) {
            results = emptyList()
            return
        }
        viewModelScope.launch {
            val url = Net.base(prefs.serverUrl) + "/users/search?q=" + URLEncoder.encode(q, "UTF-8")
            val r = Net.call("GET", url, null, prefs.token)
            r.onSuccess { j ->
                val a = j.optJSONArray("users") ?: JSONArray()
                results = (0 until a.length()).map { i ->
                    val o = a.getJSONObject(i)
                    DirUser(
                        o.getString("username"),
                        o.optString("phone"),
                        (o.optString("firstName") + " " + o.optString("lastName")).trim()
                    )
                }
            }
        }
    }

    // ---------- сообщения ----------

    fun send(chatId: String, text: String) {
        messages.add(ChatMessage(chatId, text, true))
        updateLast(chatId, text)
        save()
        val payload = JSONObject()
            .put("type", "msg")
            .put("to", chatId)
            .put("text", text)
            .put("id", UUID.randomUUID().toString())
            .toString()
        val s = socket
        if (s == null || !online || !s.send(payload)) pending.add(payload)
    }

    private fun handleIncoming(text: String) {
        val j = try { JSONObject(text) } catch (e: Exception) { return }
        if (j.optString("type") == "msg") {
            val from = j.optString("from")
            val body = j.optString("text")
            if (from.isEmpty() || body.isEmpty()) return
            ensureChat(from, j.optString("fromName"))
            messages.add(ChatMessage(from, body, false))
            updateLast(from, body)
            save()
        }
    }

    private fun post(block: () -> Unit) {
        viewModelScope.launch(Dispatchers.Main) { block() }
    }

    // ---------- соединение с сервером (WebSocket) ----------

    fun connect() {
        if (loop?.isActive == true) return
        loop = viewModelScope.launch {
            while (true) {
                if (prefs.token.isEmpty() || prefs.serverUrl.isEmpty()) {
                    delay(3000)
                    continue
                }
                val wsUrl = Net.base(prefs.serverUrl).replaceFirst("http", "ws") + "/ws?token=" + prefs.token
                val closed = CompletableDeferred<Unit>()
                val ws = try {
                    Net.wsClient.newWebSocket(
                        Request.Builder().url(wsUrl).build(),
                        object : WebSocketListener() {
                            override fun onOpen(webSocket: WebSocket, response: Response) {
                                post {
                                    online = true
                                    pending.toList().forEach { webSocket.send(it) }
                                    pending.clear()
                                }
                            }

                            override fun onMessage(webSocket: WebSocket, text: String) {
                                post { handleIncoming(text) }
                            }

                            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                                closed.complete(Unit)
                            }

                            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                                closed.complete(Unit)
                            }
                        }
                    )
                } catch (e: Exception) {
                    delay(5000)
                    continue
                }
                socket = ws
                // Лёгкий «пульс», чтобы бесплатный сервер не засыпал, пока приложение открыто.
                val heartbeat = launch {
                    while (true) {
                        delay(25_000)
                        ws.send("{\"type\":\"ping\"}")
                    }
                }
                closed.await()
                heartbeat.cancel()
                online = false
                socket = null
                delay(4000)
            }
        }
    }

    fun disconnect() {
        loop?.cancel()
        loop = null
        socket?.close(1000, null)
        socket = null
        online = false
    }

    fun clearAll() {
        disconnect()
        chats.clear()
        messages.clear()
        results = emptyList()
        query = ""
        pending.clear()
    }

    override fun onCleared() {
        disconnect()
        super.onCleared()
    }
}
