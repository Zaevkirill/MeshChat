package com.meshchat.app.ui.messenger

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meshchat.app.ui.components.Avatar
import com.meshchat.app.ui.components.GlassCard
import com.meshchat.app.ui.components.GlassCircle
import com.meshchat.app.ui.theme.NeonCyan

/** Интерфейс звонка. Реальный WebRTC подключим в следующей версии. */
@Composable
fun CallScreen(name: String, onEnd: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )
    var muted by remember { mutableStateOf(false) }
    var video by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(Modifier.height(24.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.scale(scale)) { Avatar(name, 140.dp) }
            Spacer(Modifier.height(24.dp))
            Text(name, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Вызов…", color = NeonCyan)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "Демо-экран. Аудио/видео по WebRTC будет подключено в следующей версии.",
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            GlassCircle(if (muted) "🔇" else "🎤", { muted = !muted })
            GlassCircle(if (video) "📹" else "🎥", { video = !video })
            GlassCircle("✕", onEnd, tint = Color(0xFFEF4444))
        }
    }
}
