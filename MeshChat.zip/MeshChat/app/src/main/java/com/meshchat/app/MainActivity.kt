package com.meshchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Surface
import androidx.compose.ui.graphics.Color
import com.meshchat.app.ui.components.NeonBackground
import com.meshchat.app.ui.navigation.AppNav
import com.meshchat.app.ui.theme.MeshChatTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MeshChatTheme {
                Surface(color = Color.Transparent, contentColor = Color.White) {
                    NeonBackground { AppNav() }
                }
            }
        }
    }
}
