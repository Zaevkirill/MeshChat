package com.meshchat.app.ui.messenger

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meshchat.app.ui.components.Avatar
import com.meshchat.app.ui.components.GlassButton
import com.meshchat.app.ui.components.GlassCard
import com.meshchat.app.ui.components.GlassCircle
import com.meshchat.app.ui.components.GlassField
import com.meshchat.app.ui.theme.NeonCyan
import kotlinx.coroutines.delay

@Composable
fun ChatListScreen(
    vm: MessengerViewModel,
    onOpenChat: (String) -> Unit,
    onSettings: () -> Unit
) {
    LaunchedEffect(Unit) { vm.connect() }
    LaunchedEffect(vm.query) {
        delay(400)
        vm.search()
    }
    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Чаты", fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Text(
                        when {
                            vm.online -> "Онлайн · подключено к серверу"
                            vm.meshEnabled -> "Mesh (поиск рядом) · сервер недоступен"
                            else -> "Нет связи с сервером…"
                        },
                        color = NeonCyan, fontSize = 13.sp
                    )
                }
                GlassCircle("⚙", onSettings, size = 48.dp)
            }
        }
        item {
            GlassField(vm.query, { vm.query = it }, "Поиск: @username или телефон", Modifier.fillMaxWidth())
        }
        items(vm.results, key = { "r_" + it.username }) { u ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(u.name.ifBlank { u.username })
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(u.name.ifBlank { u.username }, fontWeight = FontWeight.SemiBold)
                        Text("@${u.username}" + (if (u.phone.isNotBlank()) " · ${u.phone}" else ""), fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (vm.isContact(u)) {
                    Text("✓ Уже в контактах", color = NeonCyan, fontSize = 13.sp)
                } else {
                    GlassButton("Добавить в контакты", { vm.addContact(u) }, Modifier.fillMaxWidth())
                }
            }
        }
        items(vm.chats, key = { it.id }) { c ->
            GlassCard(Modifier.fillMaxWidth(), onClick = { onOpenChat(c.id) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(c.name, fontWeight = FontWeight.SemiBold)
                        Text(
                            c.last, fontSize = 13.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}
