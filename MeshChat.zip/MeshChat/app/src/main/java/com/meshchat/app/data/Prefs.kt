package com.meshchat.app.data

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("meshchat", Context.MODE_PRIVATE)

    private fun s(key: String): String = sp.getString(key, "") ?: ""
    private fun put(key: String, v: String) = sp.edit().putString(key, v).apply()

    var serverUrl: String
        get() = s("server")
        set(v) = put("server", v)
    var token: String
        get() = s("token")
        set(v) = put("token", v)
    var username: String
        get() = s("username")
        set(v) = put("username", v)
    var firstName: String
        get() = s("first")
        set(v) = put("first", v)
    var lastName: String
        get() = s("last")
        set(v) = put("last", v)
    var phone: String
        get() = s("phone")
        set(v) = put("phone", v)
    var email: String
        get() = s("email")
        set(v) = put("email", v)
    var chatsJson: String
        get() = s("chats")
        set(v) = put("chats", v)
    var messagesJson: String
        get() = s("messages")
        set(v) = put("messages", v)

    fun clearSession() {
        sp.edit()
            .remove("token").remove("username").remove("first").remove("last")
            .remove("phone").remove("email").remove("chats").remove("messages")
            .apply()
    }
}
