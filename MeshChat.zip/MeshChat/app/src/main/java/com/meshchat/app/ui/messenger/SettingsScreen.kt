package com.meshchat.app.ui.messenger

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meshchat.app.ui.auth.AuthViewModel
import com.meshchat.app.ui.components.Avatar
import com.meshchat.app.ui.components.GlassButton
import com.meshchat.app.ui.components.GlassCard
import com.meshchat.app.ui.components.GlassCircle
import com.meshchat.app.ui.theme.NeonCyan

@Composable
fun SettingsScreen(auth: AuthViewModel, vm: MessengerViewModel, onBack: () -> Unit, onLogout: () -> Unit) {
    val perms = remember {
        buildList {
            if (Build.VERSION.SDK_INT >= 31) {
                add(Manifest.permission.BLUETOOTH_SCAN)
                add(Manifest.permission.BLUETOOTH_ADVERTISE)
                add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.NEARBY_WIFI_DEVICES)
            add(Manifest.permission.ACCESS_FINE_LOCATION)
        }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { res -> if (res.values.all { it }) vm.meshEnabled = true }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            GlassCircle("←", onBack, size = 44.dp)
            Spacer(Modifier.width(12.dp))
            Text("Настройки", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))

        GlassCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(auth.fullName.ifBlank { "?" }, 64.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(auth.fullName.ifBlank { "Без имени" }, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("@${auth.username}", color = NeonCyan)
                    Text(auth.email, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Сервер", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(auth.serverUrl, fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f))
            Text(
                if (vm.online) "● Подключено" else "○ Нет связи",
                color = if (vm.online) NeonCyan else Color(0xFFFCA5A5), fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(16.dp))

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Mesh-сеть", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            SwitchRow("Включить Mesh", "Связь напрямую между телефонами", vm.meshEnabled, true) { on ->
                if (on) launcher.launch(perms) else vm.meshEnabled = false
            }
            SwitchRow("Bluetooth LE", "Поиск устройств рядом", vm.bleEnabled, vm.meshEnabled) { vm.bleEnabled = it }
            SwitchRow("Wi-Fi Direct", "Передача данных без роутера", vm.wifiDirectEnabled, vm.meshEnabled) {
                vm.wifiDirectEnabled = it
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Сейчас тумблеры запрашивают разрешения и меняют режим. Сам BLE/Wi-Fi Direct транспорт добавим в следующей версии.",
                fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
            )
        }
        Spacer(Modifier.height(24.dp))
        GlassButton("Выйти из аккаунта", onLogout, Modifier.fillMaxWidth())
    }
}

@Composable
private fun SwitchRow(
    title: String,
    sub: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
