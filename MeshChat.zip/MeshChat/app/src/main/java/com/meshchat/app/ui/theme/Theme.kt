package com.meshchat.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val NeonCyan = Color(0xFF22D3EE)
val NeonPurple = Color(0xFF7C3AED)
val NeonPink = Color(0xFFEC4899)
val DeepBg = Color(0xFF0B0720)

@Composable
fun MeshChatTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NeonCyan,
            secondary = NeonPurple,
            tertiary = NeonPink,
            background = DeepBg,
            surface = DeepBg,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White,
            onSurfaceVariant = Color(0xFFCBD5E1)
        ),
        content = content
    )
}
