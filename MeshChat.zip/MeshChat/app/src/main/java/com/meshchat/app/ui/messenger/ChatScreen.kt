package com.meshchat.app.ui.messenger

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meshchat.app.ui.components.Avatar
import com.meshchat.app.ui.components.GlassCircle
import com.meshchat.app.ui.components.GlassField
import com.meshchat.app.ui.theme.NeonCyan
import com.meshchat.app.ui.theme.NeonPurple

@Composable
fun ChatScreen(vm: MessengerViewModel, chatId: String, onBack: () -> Unit, onCall: () -> Unit) {
    val chat = vm.chats.firstOrNull { it.id == chatId }
    val msgs = vm.messages.filter { it.chatId == chatId }
    var text by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex)
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassCircle("←", onBack, size = 44.dp)
            Spacer(Modifier.width(12.dp))
            Avatar(chat?.name ?: "?", 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(chat?.name ?: "", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(chat?.username ?: "", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
            }
            GlassCircle("📞", onCall, size = 44.dp)
            Spacer(Modifier.width(8.dp))
            GlassCircle("🎥", onCall, size = 44.dp)
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(msgs) { m -> Bubble(m) }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            GlassField(text, { text = it }, "Сообщение", Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            GlassCircle("➤", {
                if (text.isNotBlank()) {
                    vm.send(chatId, text.trim())
                    text = ""
                }
            }, size = 52.dp)
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    val shape = RoundedCornerShape(20.dp)
    val brush = if (m.mine) {
        Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.55f), NeonPurple.copy(alpha = 0.65f)))
    } else {
        Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.08f)))
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start
    ) {
        Box(
            Modifier
                .widthIn(max = 280.dp)
                .clip(shape)
                .background(brush)
                .border(1.dp, Color.White.copy(alpha = 0.2f), shape)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(m.text)
        }
    }
}
