package com.meshchat.app.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.meshchat.app.ui.auth.AuthViewModel
import com.meshchat.app.ui.auth.EmailScreen
import com.meshchat.app.ui.auth.NameScreen
import com.meshchat.app.ui.auth.OtpScreen
import com.meshchat.app.ui.auth.UsernameScreen
import com.meshchat.app.ui.messenger.CallScreen
import com.meshchat.app.ui.messenger.ChatListScreen
import com.meshchat.app.ui.messenger.ChatScreen
import com.meshchat.app.ui.messenger.MessengerViewModel
import com.meshchat.app.ui.messenger.SettingsScreen

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val auth: AuthViewModel = viewModel()
    val msg: MessengerViewModel = viewModel()
    val start = remember { if (auth.token.isNotEmpty()) "chats" else "email" }

    NavHost(
        navController = nav,
        startDestination = start,
        enterTransition = { slideInHorizontally(tween(350)) { it / 4 } + fadeIn(tween(350)) },
        exitTransition = { slideOutHorizontally(tween(350)) { -it / 4 } + fadeOut(tween(250)) },
        popEnterTransition = { slideInHorizontally(tween(350)) { -it / 4 } + fadeIn(tween(350)) },
        popExitTransition = { slideOutHorizontally(tween(350)) { it / 4 } + fadeOut(tween(250)) }
    ) {
        composable("email") { EmailScreen(auth) { nav.navigate("otp") } }
        composable("otp") {
            OtpScreen(
                auth,
                onLoggedIn = { nav.navigate("chats") { popUpTo("email") { inclusive = true } } },
                onNew = { nav.navigate("username") }
            )
        }
        composable("username") { UsernameScreen(auth) { nav.navigate("name") } }
        composable("name") {
            NameScreen(auth) {
                nav.navigate("chats") { popUpTo("email") { inclusive = true } }
            }
        }
        composable("chats") {
            ChatListScreen(
                vm = msg,
                onOpenChat = { nav.navigate("chat/$it") },
                onSettings = { nav.navigate("settings") }
            )
        }
        composable("chat/{id}") { entry ->
            val id = entry.arguments?.getString("id") ?: ""
            ChatScreen(
                vm = msg,
                chatId = id,
                onBack = { nav.popBackStack() },
                onCall = { nav.navigate("call/$id") }
            )
        }
        composable("call/{id}") { entry ->
            val id = entry.arguments?.getString("id") ?: ""
            val name = msg.chats.firstOrNull { it.id == id }?.name ?: ""
            CallScreen(name) { nav.popBackStack() }
        }
        composable("settings") {
            SettingsScreen(
                auth, msg,
                onBack = { nav.popBackStack() },
                onLogout = {
                    msg.clearAll()
                    auth.logout()
                    nav.navigate("email") { popUpTo(nav.graph.id) { inclusive = true } }
                }
            )
        }
    }
}
