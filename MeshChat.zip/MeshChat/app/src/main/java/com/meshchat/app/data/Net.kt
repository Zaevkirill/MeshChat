package com.meshchat.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Net {
    // Длинные таймауты: бесплатный сервер может просыпаться около минуты.
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(90, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    val wsClient: OkHttpClient = client.newBuilder()
        .readTimeout(0, TimeUnit.SECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()

    fun base(raw: String): String {
        var s = raw.trim().trimEnd('/')
        if (s.isNotEmpty() && !s.startsWith("http://") && !s.startsWith("https://")) s = "https://$s"
        return s
    }

    suspend fun call(
        method: String,
        url: String,
        body: JSONObject? = null,
        token: String? = null
    ): Result<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val b = Request.Builder().url(url)
            if (!token.isNullOrEmpty()) b.header("Authorization", "Bearer $token")
            if (method == "POST") {
                b.post((body ?: JSONObject()).toString().toRequestBody("application/json".toMediaType()))
            } else {
                b.get()
            }
            client.newCall(b.build()).execute().use { r ->
                val text = r.body?.string().orEmpty()
                val json = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
                if (r.isSuccessful) {
                    Result.success(json)
                } else {
                    Result.failure(Exception(json.optString("error", "Ошибка сервера (${r.code})")))
                }
            }
        } catch (e: Exception) {
            Result.failure(Exception("Нет связи с сервером. Проверьте адрес и интернет."))
        }
    }
}
