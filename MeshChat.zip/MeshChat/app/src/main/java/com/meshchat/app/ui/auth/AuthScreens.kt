package com.meshchat.app.ui.auth

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meshchat.app.ui.components.GlassButton
import com.meshchat.app.ui.components.GlassCard
import com.meshchat.app.ui.components.GlassField
import com.meshchat.app.ui.theme.NeonCyan

@Composable
private fun AuthScaffold(
    step: Int,
    title: String,
    subtitle: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Spacer(Modifier.height(32.dp))
        Text("Шаг $step из 4", color = NeonCyan, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        Text(title, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Color.White.copy(alpha = 0.7f))
        Spacer(Modifier.height(24.dp))
        GlassCard(Modifier.fillMaxWidth(), content = content)
    }
}

@Composable
private fun ErrorLine(text: String?) {
    if (!text.isNullOrBlank()) {
        Spacer(Modifier.height(10.dp))
        Text(text, color = Color(0xFFFCA5A5), fontSize = 13.sp)
    }
}

@Composable
fun EmailScreen(vm: AuthViewModel, onNext: () -> Unit) {
    AuthScaffold(1, "Вход", "Введите e-mail, мы отправим код подтверждения") {
        GlassField(
            vm.serverUrl, { vm.serverUrl = it },
            "Адрес сервера (https://…onrender.com)", Modifier.fillMaxWidth(), KeyboardType.Uri
        )
        Spacer(Modifier.height(12.dp))
        GlassField(vm.email, { vm.email = it }, "E-mail", Modifier.fillMaxWidth(), KeyboardType.Email)
        Spacer(Modifier.height(16.dp))
        GlassButton(
            if (vm.busy) "Подождите…" else "Получить код",
            { vm.sendCode(onNext) },
            Modifier.fillMaxWidth(),
            enabled = vm.emailValid && vm.serverUrl.isNotBlank() && !vm.busy
        )
        ErrorLine(vm.error)
        Spacer(Modifier.height(12.dp))
        Text(
            "Бесплатный сервер может «просыпаться» до минуты — это нормально, дождитесь ответа.",
            fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
        )
    }
}

@Composable
fun OtpScreen(vm: AuthViewModel, onLoggedIn: () -> Unit, onNew: () -> Unit) {
    AuthScaffold(2, "Код из письма", "Введите 6 цифр, отправленных на ${vm.email}") {
        GlassField(
            vm.otp,
            { if (it.length <= 6 && it.all(Char::isDigit)) vm.otp = it },
            "6-значный код", Modifier.fillMaxWidth(), KeyboardType.NumberPassword
        )
        Spacer(Modifier.height(16.dp))
        GlassButton(
            if (vm.busy) "Проверяем…" else "Подтвердить",
            { vm.verify(onLoggedIn, onNew) },
            Modifier.fillMaxWidth(),
            enabled = vm.otpValid && !vm.busy
        )
        ErrorLine(vm.error)
        Spacer(Modifier.height(14.dp))
        Text(
            "Отправить код ещё раз",
            color = NeonCyan, fontSize = 14.sp,
            modifier = Modifier.clickable(enabled = !vm.busy) { vm.sendCode {} }
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "Проверьте папку «Спам», если письма нет.",
            fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
        )
    }
}

@Composable
fun UsernameScreen(vm: AuthViewModel, onNext: () -> Unit) {
    AuthScaffold(3, "Ваш @username", "Уникальное имя, по которому вас найдут друзья") {
        GlassField(
            vm.username,
            { vm.username = it.removePrefix("@").take(20) },
            "Username", Modifier.fillMaxWidth(),
            prefix = { Text("@") }
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "4–20 символов: латиница, цифры и «_», начинается с буквы",
            fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f)
        )
        Spacer(Modifier.height(16.dp))
        GlassButton(
            if (vm.busy) "Проверяем…" else "Далее",
            { vm.checkUsername(onNext) },
            Modifier.fillMaxWidth(),
            enabled = vm.usernameValid && !vm.busy
        )
        ErrorLine(vm.error)
    }
}

@Composable
fun NameScreen(vm: AuthViewModel, onDone: () -> Unit) {
    AuthScaffold(4, "Как вас зовут?", "Имя и фамилия увидят ваши контакты") {
        GlassField(vm.firstName, { vm.firstName = it }, "Имя", Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        GlassField(vm.lastName, { vm.lastName = it }, "Фамилия", Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        GlassField(
            vm.phone, { vm.phone = it }, "Телефон (по нему вас смогут найти)",
            Modifier.fillMaxWidth(), KeyboardType.Phone
        )
        Spacer(Modifier.height(16.dp))
        GlassButton(
            if (vm.busy) "Создаём профиль…" else "Готово",
            { vm.register(onDone) },
            Modifier.fillMaxWidth(),
            enabled = vm.nameValid && !vm.busy
        )
        ErrorLine(vm.error)
    }
}
