package com.meshchat.app.ui.auth

import android.app.Application
import android.util.Patterns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.meshchat.app.data.Net
import com.meshchat.app.data.Prefs
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.URLEncoder

class AuthViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs(app)

    var serverUrl by mutableStateOf(prefs.serverUrl)
    var email by mutableStateOf(prefs.email)
    var otp by mutableStateOf("")
    var username by mutableStateOf(prefs.username)
    var firstName by mutableStateOf(prefs.firstName)
    var lastName by mutableStateOf(prefs.lastName)
    var phone by mutableStateOf(prefs.phone)
    var token by mutableStateOf(prefs.token)
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    private var ticket = ""

    val emailValid: Boolean get() = Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
    val otpValid: Boolean get() = otp.length == 6
    val usernameValid: Boolean get() = Regex("^[A-Za-z][A-Za-z0-9_]{3,19}$").matches(username)
    val nameValid: Boolean get() = firstName.isNotBlank() && lastName.isNotBlank()
    val fullName: String get() = "${firstName.trim()} ${lastName.trim()}".trim()

    private fun base() = Net.base(serverUrl)

    fun sendCode(onOk: () -> Unit) {
        if (busy) return
        error = null
        busy = true
        prefs.serverUrl = base()
        viewModelScope.launch {
            val r = Net.call("POST", base() + "/auth/send-code", JSONObject().put("email", email.trim().lowercase()))
            busy = false
            r.onSuccess { onOk() }.onFailure { error = it.message }
        }
    }

    fun verify(onLoggedIn: () -> Unit, onNew: () -> Unit) {
        if (busy) return
        error = null
        busy = true
        viewModelScope.launch {
            val body = JSONObject().put("email", email.trim().lowercase()).put("code", otp)
            val r = Net.call("POST", base() + "/auth/verify", body)
            busy = false
            r.onSuccess { j ->
                if (j.optBoolean("registered")) {
                    applySession(j)
                    onLoggedIn()
                } else {
                    ticket = j.optString("ticket")
                    onNew()
                }
            }.onFailure { error = it.message }
        }
    }

    fun checkUsername(onOk: () -> Unit) {
        if (busy) return
        error = null
        busy = true
        viewModelScope.launch {
            val u = URLEncoder.encode(username, "UTF-8")
            val r = Net.call("GET", base() + "/auth/username-check?username=" + u)
            busy = false
            r.onSuccess { j ->
                if (j.optBoolean("available")) {
                    onOk()
                } else {
                    error = "Этот username занят, выберите другой"
                }
            }.onFailure { error = it.message }
        }
    }

    fun register(onDone: () -> Unit) {
        if (busy) return
        error = null
        busy = true
        viewModelScope.launch {
            val body = JSONObject()
                .put("ticket", ticket)
                .put("email", email.trim().lowercase())
                .put("username", username)
                .put("firstName", firstName.trim())
                .put("lastName", lastName.trim())
                .put("phone", phone.trim())
            val r = Net.call("POST", base() + "/auth/register", body)
            busy = false
            r.onSuccess { j ->
                applySession(j)
                onDone()
            }.onFailure { error = it.message }
        }
    }

    private fun applySession(j: JSONObject) {
        val u = j.getJSONObject("user")
        token = j.getString("token")
        username = u.optString("username")
        firstName = u.optString("firstName")
        lastName = u.optString("lastName")
        phone = u.optString("phone")
        prefs.token = token
        prefs.username = username
        prefs.firstName = firstName
        prefs.lastName = lastName
        prefs.phone = phone
        prefs.email = email.trim().lowercase()
    }

    fun logout() {
        prefs.clearSession()
        token = ""
        otp = ""
        username = ""
        firstName = ""
        lastName = ""
        phone = ""
        ticket = ""
        error = null
    }
}
